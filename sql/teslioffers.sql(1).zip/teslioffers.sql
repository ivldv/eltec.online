-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 06 2019 г., 12:27
-- Версия сервера: 5.6.45
-- Версия PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `myegorie_wptest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `teslioffers`
--

CREATE TABLE `teslioffers` (
  `id` varchar(50) NOT NULL,
  `url` varchar(200) NOT NULL,
  `categoryid` varchar(50) NOT NULL,
  `model` varchar(250) NOT NULL,
  `mainimage` varchar(250) NOT NULL,
  `step_count` int(11) NOT NULL,
  `producer` varchar(200) NOT NULL,
  `vendorcode` varchar(40) NOT NULL,
  `series` varchar(200) NOT NULL,
  `discountcode` varchar(50) NOT NULL,
  `imgid` int(11) NOT NULL,
  `paramid` int(11) NOT NULL,
  `internalid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `teslioffers`
--

INSERT INTO `teslioffers` (`id`, `url`, `categoryid`, `model`, `mainimage`, `step_count`, `producer`, `vendorcode`, `series`, `discountcode`, `imgid`, `paramid`, `internalid`) VALUES
('9a4b7791-c0ff-11e5-84d2-0cc47a13d3da', 'https://www.tesli.com/product/korobka-otkrytogo-montazha-1-mestnaya-schneider-electric-glossa-191708/', 'db710657-ba27-4245-9c12-5ab37f50a962', 'Glossa Коробка накладного монтажа, перламутр', 'https://www.tesli.com/upload/iblock/42a/9a4b7791_c0ff_11e5_84d2_0cc47a13d3da.jpg', 1, 'Schneider Electric', 'GSL000600', 'GLOSSA', 'b530121c-5b1d-11e3-8764-00259096c80e', 0, 0, 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `teslioffers`
--
ALTER TABLE `teslioffers`
  ADD PRIMARY KEY (`internalid`,`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `teslioffers`
--
ALTER TABLE `teslioffers`
  MODIFY `internalid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=502604;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
